define(function (require) {
    //Important, notice the space between require and arg calls
    var b = require ('b');

    return {
        name: 'a',
        b: b
    };
});
