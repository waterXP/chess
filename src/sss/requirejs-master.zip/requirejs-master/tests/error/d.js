define(['b'], function (b) {
    return {
       name: 'd',
       b: b
    };
});

