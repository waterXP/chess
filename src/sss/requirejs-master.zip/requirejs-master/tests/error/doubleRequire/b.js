define(['myShim'], function (broken) {
  return { name: 'b' };
});
