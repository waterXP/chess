define({
    name: 'toString'
});