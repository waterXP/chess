define({
    "root": {
        red: "red",
        blue: "blue",
        green: "green",
        black: {
            opacity: 1,
            rgb: {
                r: "0",
                g: "0",
                b: "0"
            }
        }
    },
    "en-us-surfer": true,
    "fr": true
});
