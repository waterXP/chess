define("lamp", {
    color: "blue"
});
