define(['d'], function(d) {
    d.adapted = true;
    return d;
});
