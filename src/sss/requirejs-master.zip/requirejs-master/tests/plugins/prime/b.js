define(function () {
    return {
        name: "bPrime"
    };
});
