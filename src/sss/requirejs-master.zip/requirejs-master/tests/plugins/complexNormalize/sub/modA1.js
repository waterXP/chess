define(['./modA2'], function(modAName) { return modAName; });
