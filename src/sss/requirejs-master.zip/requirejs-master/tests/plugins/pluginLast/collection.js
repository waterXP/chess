define(['collectionHelper'], function (collectionHelper) {
    return {
        name: 'collection',
        collectionHelperName: collectionHelper.name,
        componentName: collectionHelper.componentName,
        componentHtml: collectionHelper.componentHtml
    };
});
