define(function (require, exports) {
    this.name = 'usethis';
});
